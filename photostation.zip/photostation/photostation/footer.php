<footer>
        <p class="logo-text">Photo Station</p>
        <p>Favorite people and hottest trends!</p>
        <p>Copyright &copy; 2000 - 2022 The Photo Station ltd.</p>
    </footer>
    <script src="site.js"></script>
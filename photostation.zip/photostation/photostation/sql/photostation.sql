-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2023 at 11:25 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `photostation`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `creatorid` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `startdate` datetime DEFAULT NULL,
  `enddate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookingid`, `userid`, `creatorid`, `status`, `amount`, `startdate`, `enddate`) VALUES
(1, 1, 1, 'approved', '200', '2023-01-26 10:20:09', '2023-01-28 10:20:17'),
(2, 2, 1, 'approved', '250', '2023-01-29 15:55:00', '2023-02-01 15:55:00'),
(3, 1, 1, 'pending', '250', '2023-01-30 16:14:00', '2023-02-10 16:14:00'),
(6, 1, 3, 'approved', '250', '2023-01-25 17:18:00', '2023-01-30 17:18:00'),
(7, 1, 1, 'pending', '100', '2023-01-30 14:05:00', '2023-01-31 14:05:00'),
(8, 1, 1, 'pending', '100', '2023-01-30 14:19:00', '2023-01-31 14:20:00'),
(9, 1, 1, 'pending', '100', '2023-01-30 14:22:00', '2023-01-31 14:22:00'),
(10, 1, 1, 'rejected', '600', '2023-02-02 14:41:00', '2023-02-08 14:41:00'),
(11, 1, 4, 'approved', '460', '2023-02-15 02:04:00', '2023-02-17 02:04:00'),
(12, 10, 4, 'approved', '690', '2023-02-21 02:53:00', '2023-02-24 02:53:00'),
(13, 1, 1, 'approved', '220', '2023-02-23 14:07:00', '2023-02-24 14:07:00');

-- --------------------------------------------------------

--
-- Table structure for table `bookingservice`
--

CREATE TABLE `bookingservice` (
  `bookingserviceid` int(11) NOT NULL,
  `bookingid` int(11) NOT NULL,
  `serviceid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookingservice`
--

INSERT INTO `bookingservice` (`bookingserviceid`, `bookingid`, `serviceid`) VALUES
(1, 1, 1),
(2, 6, 2),
(3, 6, 4),
(4, 7, 1),
(5, 8, 1),
(6, 9, 2),
(7, 10, 2),
(8, 11, 4),
(9, 12, 4),
(10, 13, 1);

-- --------------------------------------------------------

--
-- Table structure for table `creator`
--

CREATE TABLE `creator` (
  `creatorid` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `street` text NOT NULL,
  `bio` text NOT NULL,
  `age` int(100) NOT NULL,
  `userid` int(11) NOT NULL,
  `creatortype` enum('photographer','videographer') NOT NULL DEFAULT 'photographer',
  `path` text NOT NULL,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL DEFAULT 'pending'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `creator`
--

INSERT INTO `creator` (`creatorid`, `name`, `city`, `state`, `street`, `bio`, `age`, `userid`, `creatortype`, `path`, `createdon`, `status`) VALUES
(1, 'John Ram', 'riyad', 'riyad', 'xyz, riyad, riyad', 'test photographer bio', 26, 2, 'photographer', 'img/creator/testphotographer.jpg', '2023-01-14 03:44:32', 'approved'),
(2, 'Vicky', 'riyad', 'riyad', 'riyah, street 1, test', 'Hire me for any video graphy', 26, 3, 'videographer', 'img/creator/testvideographer.jpg', '2022-12-28 09:44:32', 'pending'),
(3, 'James', 'Medina', 'Medina', 'rthyjyh', 'Hire me', 25, 4, 'photographer', 'img/creator/photop1.jpg', '2023-01-28 03:44:32', 'approved'),
(4, 'Rom', 'Mecca', 'Mecca', 'fghsaa', 'The best photographer', 27, 5, 'photographer', 'img/creator/photop2.jpg', '2022-06-06 03:44:32', 'rejected'),
(5, 'Wick', 'Tabuk', 'Tabuk', 'rthyjyh', 'Try first! Pay Later!', 26, 6, 'videographer', 'img/creator/vidv1.jpg', '2023-01-28 03:44:32', 'approved'),
(6, 'Will goff', 'Mecca', 'Mecca', 'fghsaa', 'Contact me for that', 36, 7, 'videographer', 'img/creator/vidv2.jpg', '2023-01-01 10:44:32', 'pending'),
(7, 'testtt', 'sdfg', 'dfg', 'fdf', 'dfghf', 21, 12, 'photographer', 'dfghn', '2023-02-06 08:46:38', 'pending'),
(9, 'test last', 'edf', 'sdf', 'sdff', 'this is bio', 34, 13, 'videographer', 'img/creator/testlast_coop.jpeg', '2023-02-06 09:47:39', 'rejected');

-- --------------------------------------------------------

--
-- Table structure for table `creatorservice`
--

CREATE TABLE `creatorservice` (
  `creatorserviceid` int(11) NOT NULL,
  `creatorid` int(11) NOT NULL,
  `serviceid` int(11) NOT NULL,
  `rate` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `creatorservice`
--

INSERT INTO `creatorservice` (`creatorserviceid`, `creatorid`, `serviceid`, `rate`) VALUES
(1, 1, 1, '220'),
(2, 1, 2, '100'),
(3, 3, 2, '100'),
(4, 3, 4, '100'),
(5, 1, 3, '210'),
(6, 9, 1, '200'),
(7, 4, 4, '230');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymentid` int(11) NOT NULL,
  `bookingid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `cardnumber` varchar(200) NOT NULL,
  `cardname` varchar(200) NOT NULL,
  `cvc` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`paymentid`, `bookingid`, `total`, `cardnumber`, `cardname`, `cvc`, `type`, `userid`) VALUES
(1, 6, 313, '45675435', 'xyz', '343', 'visa', 1),
(4, 12, 863, '54346', 'test', '232', 'visa', 10),
(7, 1, 250, '32445', 'tse', '232', 'visa', 1),
(8, 11, 575, '845641236545632', 'rupay', '083', 'credit card', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `ratingid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `creatorid` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`ratingid`, `userid`, `creatorid`, `rating`, `comment`) VALUES
(1, 1, 4, 4, ''),
(2, 10, 4, 3, ''),
(3, 1, 1, 4, 'thanks for your services'),
(4, 1, 3, 5, 'thanks');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `serviceid` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`serviceid`, `name`) VALUES
(1, 'wedding'),
(2, 'pre-wedding'),
(3, 'Engagement'),
(4, 'Baby Ceremony');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `role` enum('admin','creator','customer') NOT NULL DEFAULT 'customer'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `role`) VALUES
(1, 'testuser', '12345', 'customer'),
(2, 'testphotographer', '12345', 'creator'),
(3, 'testvideographer', '1234', 'creator'),
(4, 'photop1', '12345', 'creator'),
(5, 'photop2', '12345', 'creator'),
(6, 'vidv1', '12345', 'creator'),
(7, 'vidv2', '12345', 'creator'),
(8, 'admin', '12345', 'admin'),
(9, 'test1223', '12345', 'customer'),
(10, 'creatortest1', '12345', 'customer'),
(11, 'testas1', '12345', 'creator'),
(13, 'testlast', '12345', 'creator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingid`);

--
-- Indexes for table `bookingservice`
--
ALTER TABLE `bookingservice`
  ADD PRIMARY KEY (`bookingserviceid`);

--
-- Indexes for table `creator`
--
ALTER TABLE `creator`
  ADD PRIMARY KEY (`creatorid`);

--
-- Indexes for table `creatorservice`
--
ALTER TABLE `creatorservice`
  ADD PRIMARY KEY (`creatorserviceid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymentid`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`ratingid`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`serviceid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `bookingservice`
--
ALTER TABLE `bookingservice`
  MODIFY `bookingserviceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `creator`
--
ALTER TABLE `creator`
  MODIFY `creatorid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `creatorservice`
--
ALTER TABLE `creatorservice`
  MODIFY `creatorserviceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `paymentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `ratingid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `serviceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php 
	error_reporting(E_ERROR);
	$conn = mysqli_connect('localhost','root','','photostation');
	// $conn = mysqli_connect('localhost','root','root','photostation','8888');

?>
